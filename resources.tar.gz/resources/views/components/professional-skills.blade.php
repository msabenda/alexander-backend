<!-- ----------------------------------------------PROFESSIONAL SKILLS----------------------------------------- -->

<!-- <section class="skills" id="skills-id"> -->
  <!-- Flex container for both skill containers -->
  <!-- <div class="skills-container"> -->
    <!-- div for container1 on left side -->
    <!-- <div class="container1">
      <h1 class="section-heading1">Professional Skills</h1>
      <div class="technical-bar">
        <div class="bar">
          <i class="fa-solid fa-marker" style="margin-bottom: 5px;"></i>
          <div class="info">
            <span>Graphics Design</span>
          </div>
          <div class="progress-line graphics">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-video" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Motion Graphics</span>
          </div>
          <div class="progress-line motion">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-desktop" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Branding</span>
          </div>
          <div class="progress-line branding">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-rectangle-ad" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Poster and Advertisement</span>
          </div>
          <div class="progress-line poster">
            <span></span>
          </div>
        </div> -->
        <!-- Add more div for skills here if needed -->
      <!-- </div> -->
    <!-- </div> -->

    <!-- div for container2 on right side -->
    <!-- <div class="container2"> -->
      <!-- Additional Skills -->
      <!-- <h1 class="section-heading1">Technical Skills</h1>
      <div class="technical-bar">
        <div class="bar">
          <i class="fa-solid fa-lightbulb" style="margin-bottom: 5px;"></i>
          <div class="info">
            <span>Creative Thinking</span>
          </div>
          <div class="progress-line creative-thinking">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-tools" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Technical Skills</span>
          </div>
          <div class="progress-line technical-skills">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-people-group" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Team Collaboration</span>
          </div>
          <div class="progress-line team-collaboration">
            <span></span>
          </div>
        </div>

        <div class="bar">
          <i class="fa-solid fa-calendar" style="margin-top: 30px;"></i>
          <div class="info">
            <span>Project Management</span>
          </div>
          <div class="progress-line project-management">
            <span></span>
          </div>
        </div> -->
        <!-- Add more div for additional skills here if needed -->
      <!-- </div> -->
    <!-- </div> -->
  <!-- </div> End of skills-container -->
<!-- </section> Professional ends here -->
