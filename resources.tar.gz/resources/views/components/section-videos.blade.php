<!-- --------------Videos-------------------- -->
 <section id="video-section">

 <header> 
 <h2 class="section-heading"><span class="videoZ">My </span><span class="videoz">VIDEOS</span></h2>
  </header>
<div class="container-videos">
		<div class="main-video-container">
			<video src="{{ url('videos/6.mp4') }}" loop controls class="main-video"></video>
			<h3 class="main-vid-title">YUNA Organization</h3>
		</div>
		<div class="video-list-container" id="videosList"></div>
	</div>
 </section>
