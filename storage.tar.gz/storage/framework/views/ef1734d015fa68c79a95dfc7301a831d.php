<section class="logos">
<h2 class="section-heading"><span class="myClient">My </span><span class="clieent">CLIENTS</span></h2>
      <div class="logos-slide">
        <img src="<?php echo e(url('images/i.png')); ?>"/>
        <img src="<?php echo e(url('images/ii.png')); ?>" />
        <img src="<?php echo e(url('images/iii.png')); ?>" />
        <img src="<?php echo e(url('images/iv.png')); ?>" />
        <img src="<?php echo e(url('images/v.png')); ?>" />
        <img src="<?php echo e(url('images/vi.png')); ?>" />
        <img src="<?php echo e(url('images/vii.png')); ?>" />
        <img src="<?php echo e(url('images/ii.png')); ?>" />
        <img src="<?php echo e(url('images/ix.png')); ?>" />
        <img src="<?php echo e(url('images/x.png')); ?>" />
        <img src="<?php echo e(url('images/xi.png')); ?>" />
        
      </div>
</section>

    <script>
      var copy = document.querySelector(".logos-slide").cloneNode(true);
      document.querySelector(".logos").appendChild(copy);
    </script><?php /**PATH /home/msabenda/My PROJECTS/New/alexander-backend/resources/views/components/clients-section.blade.php ENDPATH**/ ?>