<!DOCTYPE html>
<html>
<head>
    <title>New Contact Form Submission</title>
</head>
<body>
    <h2>New Contact Form Submission</h2>
    <p><strong>Name:</strong> <?php echo e($contactData['name']); ?></p>
    <p><strong>Email:</strong> <?php echo e($contactData['email']); ?></p>
    <p><strong>Phone:</strong> <?php echo e($contactData['phone']); ?></p>
    <p><strong>Service:</strong> <?php echo e($contactData['service']); ?></p>
    <p><strong>Message:</strong> <?php echo e($contactData['message']); ?></p>
</body>
</html>
<?php /**PATH /home/msabenda/My PROJECTS/New/alexander-backend/resources/views/emails/contact.blade.php ENDPATH**/ ?>