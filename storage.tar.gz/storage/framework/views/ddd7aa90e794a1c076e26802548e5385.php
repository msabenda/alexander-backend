<!-- Extends layout from app.blade.php -->



<!-- Display the injected content -->
<?php $__env->startSection('content'); ?>

<!-- Home section component -->
 <?php if (isset($component)) { $__componentOriginal79838b60d36b84894208103b1a7a142f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79838b60d36b84894208103b1a7a142f = $attributes; } ?>
<?php $component = App\View\Components\HomeSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HomeSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79838b60d36b84894208103b1a7a142f)): ?>
<?php $attributes = $__attributesOriginal79838b60d36b84894208103b1a7a142f; ?>
<?php unset($__attributesOriginal79838b60d36b84894208103b1a7a142f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79838b60d36b84894208103b1a7a142f)): ?>
<?php $component = $__componentOriginal79838b60d36b84894208103b1a7a142f; ?>
<?php unset($__componentOriginal79838b60d36b84894208103b1a7a142f); ?>
<?php endif; ?>

 <!-- About section component -->
 <?php if (isset($component)) { $__componentOriginalaa1dc9a2adb4589988536ab9fa557489 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalaa1dc9a2adb4589988536ab9fa557489 = $attributes; } ?>
<?php $component = App\View\Components\AboutSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('about-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AboutSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalaa1dc9a2adb4589988536ab9fa557489)): ?>
<?php $attributes = $__attributesOriginalaa1dc9a2adb4589988536ab9fa557489; ?>
<?php unset($__attributesOriginalaa1dc9a2adb4589988536ab9fa557489); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalaa1dc9a2adb4589988536ab9fa557489)): ?>
<?php $component = $__componentOriginalaa1dc9a2adb4589988536ab9fa557489; ?>
<?php unset($__componentOriginalaa1dc9a2adb4589988536ab9fa557489); ?>
<?php endif; ?>
 
 <!-- Mission section component -->
<?php if (isset($component)) { $__componentOriginal816d9cf5012506cbeb9543828c345c3b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal816d9cf5012506cbeb9543828c345c3b = $attributes; } ?>
<?php $component = App\View\Components\MissionSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mission-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\MissionSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal816d9cf5012506cbeb9543828c345c3b)): ?>
<?php $attributes = $__attributesOriginal816d9cf5012506cbeb9543828c345c3b; ?>
<?php unset($__attributesOriginal816d9cf5012506cbeb9543828c345c3b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal816d9cf5012506cbeb9543828c345c3b)): ?>
<?php $component = $__componentOriginal816d9cf5012506cbeb9543828c345c3b; ?>
<?php unset($__componentOriginal816d9cf5012506cbeb9543828c345c3b); ?>
<?php endif; ?> 

<!-- Services section component -->
<?php if (isset($component)) { $__componentOriginal75fba9047c652748f487dca2d40ef033 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal75fba9047c652748f487dca2d40ef033 = $attributes; } ?>
<?php $component = App\View\Components\ServicesSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('services-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ServicesSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal75fba9047c652748f487dca2d40ef033)): ?>
<?php $attributes = $__attributesOriginal75fba9047c652748f487dca2d40ef033; ?>
<?php unset($__attributesOriginal75fba9047c652748f487dca2d40ef033); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal75fba9047c652748f487dca2d40ef033)): ?>
<?php $component = $__componentOriginal75fba9047c652748f487dca2d40ef033; ?>
<?php unset($__componentOriginal75fba9047c652748f487dca2d40ef033); ?>
<?php endif; ?>

<!-- Clients section component -->
<?php if (isset($component)) { $__componentOriginalabfb46f40e9a7611c21a7342a41ba1c2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalabfb46f40e9a7611c21a7342a41ba1c2 = $attributes; } ?>
<?php $component = App\View\Components\ClientsSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('clients-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ClientsSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalabfb46f40e9a7611c21a7342a41ba1c2)): ?>
<?php $attributes = $__attributesOriginalabfb46f40e9a7611c21a7342a41ba1c2; ?>
<?php unset($__attributesOriginalabfb46f40e9a7611c21a7342a41ba1c2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalabfb46f40e9a7611c21a7342a41ba1c2)): ?>
<?php $component = $__componentOriginalabfb46f40e9a7611c21a7342a41ba1c2; ?>
<?php unset($__componentOriginalabfb46f40e9a7611c21a7342a41ba1c2); ?>
<?php endif; ?>

<!-- Blog section component -->
<?php if (isset($component)) { $__componentOriginal872eee18bc322a4f609d2a9f6f701329 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal872eee18bc322a4f609d2a9f6f701329 = $attributes; } ?>
<?php $component = App\View\Components\BlogSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('blog-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\BlogSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal872eee18bc322a4f609d2a9f6f701329)): ?>
<?php $attributes = $__attributesOriginal872eee18bc322a4f609d2a9f6f701329; ?>
<?php unset($__attributesOriginal872eee18bc322a4f609d2a9f6f701329); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal872eee18bc322a4f609d2a9f6f701329)): ?>
<?php $component = $__componentOriginal872eee18bc322a4f609d2a9f6f701329; ?>
<?php unset($__componentOriginal872eee18bc322a4f609d2a9f6f701329); ?>
<?php endif; ?>

<!-- Pictures Project Section component -->
<?php if (isset($component)) { $__componentOriginal3791271980c5eef5b0a37568a2e44ab7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3791271980c5eef5b0a37568a2e44ab7 = $attributes; } ?>
<?php $component = App\View\Components\SectionPictures::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-pictures'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SectionPictures::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3791271980c5eef5b0a37568a2e44ab7)): ?>
<?php $attributes = $__attributesOriginal3791271980c5eef5b0a37568a2e44ab7; ?>
<?php unset($__attributesOriginal3791271980c5eef5b0a37568a2e44ab7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3791271980c5eef5b0a37568a2e44ab7)): ?>
<?php $component = $__componentOriginal3791271980c5eef5b0a37568a2e44ab7; ?>
<?php unset($__componentOriginal3791271980c5eef5b0a37568a2e44ab7); ?>
<?php endif; ?>

<!-- Videos Project Section component -->
<?php if (isset($component)) { $__componentOriginalf5669986fad6235e02ea6301fca7bea1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf5669986fad6235e02ea6301fca7bea1 = $attributes; } ?>
<?php $component = App\View\Components\SectionVideos::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section-videos'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SectionVideos::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf5669986fad6235e02ea6301fca7bea1)): ?>
<?php $attributes = $__attributesOriginalf5669986fad6235e02ea6301fca7bea1; ?>
<?php unset($__attributesOriginalf5669986fad6235e02ea6301fca7bea1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf5669986fad6235e02ea6301fca7bea1)): ?>
<?php $component = $__componentOriginalf5669986fad6235e02ea6301fca7bea1; ?>
<?php unset($__componentOriginalf5669986fad6235e02ea6301fca7bea1); ?>
<?php endif; ?>

<!-- Testimonials Section component -->
<?php if (isset($component)) { $__componentOriginal2b6c43e753bdf578b8a28d3c1ffebad8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b6c43e753bdf578b8a28d3c1ffebad8 = $attributes; } ?>
<?php $component = App\View\Components\TestimonialsSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('testimonials-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\TestimonialsSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b6c43e753bdf578b8a28d3c1ffebad8)): ?>
<?php $attributes = $__attributesOriginal2b6c43e753bdf578b8a28d3c1ffebad8; ?>
<?php unset($__attributesOriginal2b6c43e753bdf578b8a28d3c1ffebad8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b6c43e753bdf578b8a28d3c1ffebad8)): ?>
<?php $component = $__componentOriginal2b6c43e753bdf578b8a28d3c1ffebad8; ?>
<?php unset($__componentOriginal2b6c43e753bdf578b8a28d3c1ffebad8); ?>
<?php endif; ?>

<!-- Contact Section component -->
<?php if (isset($component)) { $__componentOriginal9c3dcedb3c5d0be0825038cbc90c01d9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9c3dcedb3c5d0be0825038cbc90c01d9 = $attributes; } ?>
<?php $component = App\View\Components\ContactSection::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('contact-section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\ContactSection::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9c3dcedb3c5d0be0825038cbc90c01d9)): ?>
<?php $attributes = $__attributesOriginal9c3dcedb3c5d0be0825038cbc90c01d9; ?>
<?php unset($__attributesOriginal9c3dcedb3c5d0be0825038cbc90c01d9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9c3dcedb3c5d0be0825038cbc90c01d9)): ?>
<?php $component = $__componentOriginal9c3dcedb3c5d0be0825038cbc90c01d9; ?>
<?php unset($__componentOriginal9c3dcedb3c5d0be0825038cbc90c01d9); ?>
<?php endif; ?>


<!-- // If there another sections -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/msabenda/My PROJECTS/New/alexander-backend/resources/views/welcome.blade.php ENDPATH**/ ?>